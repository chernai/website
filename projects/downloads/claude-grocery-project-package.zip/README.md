# Claude Grocery Project

A localhost dashboard that turns photos of your grocery receipts into a spend breakdown — pie chart by category, line chart by month — and answers plain-English questions like *"how much did I spend on vegetables in July?"*

Everything runs on your own laptop. No accounts beyond your Anthropic API key, no deployment, no upload buttons.

## Read these in order

1. **API_KEY_SETUP.md** — do this first, before touching the terminal
2. **copy-paste-cheatsheet.txt** — every command you'll run, in order, ready to copy/paste
3. **TEACHING_NOTES_vision.md** — for whoever's leading the session, explains why we need the vision API
4. **my-notes-template.txt** — copy this to `my-notes.txt` and use it to store your key + notes during the session

## Quick version

```
npm install
export ANTHROPIC_API_KEY=your-key-here
# add receipt photos to "Claude Grocery Project/July 2026/"
node extract-receipts.js "July 2026"
node server.js
# open http://localhost:3000
```

## Folder structure

```
Claude Grocery Project/
  July 2026/
    receipt1.jpg
    receipt2.jpg
    receipt3.jpg
    data.json          <- created automatically by extract-receipts.js
  August 2026/
    ...
```

## What's next (session 2)

This same pattern — photo in, structured data out, dashboard on top — is the seed of a full personal finance app: multiple spending categories beyond groceries, budgets, recurring expense tracking, and comparisons month over month.
