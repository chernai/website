# Getting Your API Key — Step by Step

This is the one part of setup that has to happen before the app can "read" anything. Do this first, calmly, before we start building.

## What is an API key, in plain terms?

Right now, when you use claude.ai in a browser, you log in with a password and Anthropic knows it's you. An API key is the same idea, but for when a *program* (not a browser) needs to talk to Claude. Our grocery app is a program running on your own laptop — it needs its own way to prove "this request is allowed," and that's what the key does.

Think of it like a keycard for a building instead of a name written at the front desk. The building (Claude) still checks who's coming in, just through a different method.

**Is this safe to do in a room full of people?** Yes — nothing we're building here is sensitive. We're reading grocery receipts, not medical records or financial accounts. Treat the key itself like a password though: don't post it publicly or paste it into a chat you don't control.

## Step 1 — Create an account (if you don't have one)

1. Go to **console.anthropic.com**
2. Sign up with your email (or log in if you already have a claude.ai account — same login works)

## Step 2 — Add a small amount of credit

1. Once logged in, look for **"Billing"** or **"Plans & Billing"** in the left sidebar
2. Add a small amount of credit — **$5 is more than enough** for this entire training, including everyone's receipts and questions
3. You need this step because API usage is billed separately from any claude.ai subscription you might already have

## Step 3 — Create your API key

1. In the left sidebar, click **"API Keys"**
2. Click **"Create Key"**
3. Give it any name, e.g. "grocery-training"
4. Click Create
5. **Copy the key immediately** — it starts with `sk-ant-...` and it will only be shown to you once. If you lose it, you just make a new one, no big deal.

## Step 4 — Paste it into your notes file

Open the `my-notes.txt` file on your Desktop (we'll make this in the room) and paste the key in there, labeled clearly, e.g.:

```
API KEY: sk-ant-xxxxxxxxxxxxxxxxxxxxx
```

You'll copy it from here into the terminal in a moment. Keeping it in a plain text file just for this session makes copy-pasting painless — we're not aiming for production-grade security today, just "don't post it on the internet."

## Step 5 — Set it in your terminal

This tells your laptop "use this key for anything that talks to Claude" for the current terminal session.

**On Mac:**
```
export ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxxxxxxxxxxxxx
```

**On Windows (Command Prompt):**
```
set ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxxxxxxxxxxxxx
```

**On Windows (PowerShell):**
```
$env:ANTHROPIC_API_KEY="sk-ant-xxxxxxxxxxxxxxxxxxxxx"
```

Replace the `sk-ant-...` part with your actual key from Step 3.

**Important:** this only lasts for as long as that terminal window stays open. If you close the terminal and reopen it, you'll need to run this command again before running the app.

## How you'll know it worked

No confirmation message appears — that's normal. You'll know it worked when you run the app later and it successfully reads a receipt instead of giving an error about a missing key.
