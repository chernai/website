# Teaching Moment: Why "Vision API"?

Say this out loud around Step 5, right before everyone runs `extract-receipts.js`:

---

"Claude normally reads text — you type a question, it types back. But a receipt is a **photo**, not text. Before Claude can tell us anything about it, it first has to *look* at the image and figure out what's written on it — the store name, the items, the prices — the same way you'd glance at a receipt and read it.

That 'looking at an image and understanding it' skill is called **vision**. It's a separate capability from plain text chat — which is why our script sends the photo itself to Claude, not just a description of it.

This matters because it's the same skill behind a lot of things you've probably already seen AI do: reading a screenshot, describing a photo, scanning a document. Today we're using it for receipts. It's the exact same idea Serene's team could use to read scanned invoices, or [wellness-fitness friend] could use to read a screenshot from a health app instead of typing numbers in by hand.

So when you run the next command, watch the terminal — you'll see it go receipt by receipt, and each one is Claude actually *looking* at your photo before it writes anything down."

---

**One more thing worth mentioning if someone asks "how does it know what a tomato is":** it doesn't have any grocery-specific training — it's the same general vision ability that can read a menu, a whiteboard, or a street sign. We're just pointing it at a receipt and telling it what shape of answer we want back (item name, price, category).
