// server.js
// Localhost dashboard for the Claude Grocery Project.
// Run with: node server.js
// Then open: http://localhost:3000

const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const PROJECT_FOLDER = path.join(__dirname, "Claude Grocery Project");

function loadAllData() {
  const months = fs.readdirSync(PROJECT_FOLDER, { withFileTypes: true })
    .filter(d => d.isDirectory())
    .map(d => d.name);

  const allReceipts = [];
  for (const month of months) {
    const dataPath = path.join(PROJECT_FOLDER, month, "data.json");
    if (fs.existsSync(dataPath)) {
      const parsed = JSON.parse(fs.readFileSync(dataPath, "utf-8"));
      for (const receipt of parsed.receipts) {
        allReceipts.push({ ...receipt, month });
      }
    }
  }
  return allReceipts;
}

app.get("/api/summary", (req, res) => {
  const receipts = loadAllData();

  const categoryTotals = {};
  const monthTotals = {};
  let grandTotal = 0;

  for (const receipt of receipts) {
    for (const item of receipt.items) {
      const price = Number(item.price) || 0;
      categoryTotals[item.category] = (categoryTotals[item.category] || 0) + price;
      monthTotals[receipt.month] = (monthTotals[receipt.month] || 0) + price;
      grandTotal += price;
    }
  }

  res.json({
    grandTotal: Number(grandTotal.toFixed(2)),
    categoryTotals,
    monthTotals,
    receiptCount: receipts.length
  });
});

app.post("/api/ask", async (req, res) => {
  const { question } = req.body;
  const receipts = loadAllData();

  const compactData = receipts.map(r => ({
    month: r.month,
    store: r.store,
    date: r.date,
    items: r.items
  }));

  const prompt = `Here is grocery receipt data as JSON:\n${JSON.stringify(compactData)}\n\nQuestion: "${question}"\n\nAnswer clearly and concisely, in plain English, using only this data. If it involves a total, show the number clearly (e.g. "$42.50"). If the question can't be answered from this data, say so.`;

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 500,
        messages: [{ role: "user", content: prompt }]
      })
    });
    const data = await response.json();
    const textBlock = (data.content || []).find(b => b.type === "text");
    res.json({ answer: textBlock ? textBlock.text : "No answer returned." });
  } catch (err) {
    res.status(500).json({ answer: "Error: " + err.message });
  }
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`\nClaude Grocery Project dashboard running!`);
  console.log(`Open http://localhost:${PORT} in your browser\n`);
});
