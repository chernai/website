// extract-receipts.js
// Reads every receipt photo in "Claude Grocery Project/<Month>/", asks Claude to
// read the items off each receipt, and saves the results as a single
// data.json file inside that month's folder.
//
// Run with:  node extract-receipts.js "July 2026"

const fs = require("fs");
const path = require("path");

const PROJECT_FOLDER = path.join(__dirname, "Claude Grocery Project");
const CATEGORIES = [
  "Vegetables", "Fruits", "Meat & Seafood", "Dairy & Eggs",
  "Bakery", "Snacks", "Beverages", "Household", "Other"
];

async function fileToBase64(filePath) {
  const buffer = fs.readFileSync(filePath);
  return buffer.toString("base64");
}

function mediaTypeFor(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  if (ext === ".png") return "image/png";
  if (ext === ".webp") return "image/webp";
  return "image/jpeg";
}

async function extractOneReceipt(filePath) {
  const base64 = await fileToBase64(filePath);
  const mediaType = mediaTypeFor(filePath);

  const body = {
    model: "claude-sonnet-4-6",
    max_tokens: 1500,
    messages: [
      {
        role: "user",
        content: [
          {
            type: "image",
            source: { type: "base64", media_type: mediaType, data: base64 }
          },
          {
            type: "text",
            text: `This is a photo of a grocery receipt. Extract every line item you can read.

Return ONLY valid JSON (no markdown fences, no commentary) in this exact shape:
{
  "store": "string or null if unreadable",
  "date": "YYYY-MM-DD or null if unreadable",
  "items": [
    { "name": "string, cleaned up plain-English name", "price": number, "category": "one of: ${CATEGORIES.join(", ")}" }
  ]
}

Guidelines:
- Pick the closest category from the list for every item. Use "Other" only if nothing fits.
- If price is unclear, make your best estimate rather than skipping the item.
- Ignore subtotal/tax/total lines — only include actual purchased items.
- Clean up cryptic receipt abbreviations into a readable name (e.g. "TOM CHRY 250G" -> "Cherry Tomatoes").`
          }
        ]
      }
    ]
  };

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });

  const data = await response.json();
  const textBlock = (data.content || []).find(b => b.type === "text");
  if (!textBlock) throw new Error("No text response for " + filePath);

  const cleaned = textBlock.text.replace(/```json|```/g, "").trim();
  return JSON.parse(cleaned);
}

async function main() {
  const monthArg = process.argv[2];
  if (!monthArg) {
    console.error('Usage: node extract-receipts.js "July 2026"');
    process.exit(1);
  }

  const monthFolder = path.join(PROJECT_FOLDER, monthArg);
  if (!fs.existsSync(monthFolder)) {
    console.error("Folder not found:", monthFolder);
    process.exit(1);
  }

  const imageFiles = fs.readdirSync(monthFolder)
    .filter(f => /\.(jpe?g|png|webp)$/i.test(f));

  if (imageFiles.length === 0) {
    console.log("No receipt photos found in", monthFolder);
    return;
  }

  console.log(`Found ${imageFiles.length} receipt(s) in ${monthArg}. Reading them...`);

  const receipts = [];
  for (const file of imageFiles) {
    const fullPath = path.join(monthFolder, file);
    process.stdout.write(`  - ${file} ... `);
    try {
      const result = await extractOneReceipt(fullPath);
      result.sourceFile = file;
      receipts.push(result);
      console.log(`done (${result.items.length} items)`);
    } catch (err) {
      console.log("FAILED: " + err.message);
    }
  }

  const outPath = path.join(monthFolder, "data.json");
  fs.writeFileSync(outPath, JSON.stringify({ month: monthArg, receipts }, null, 2));
  console.log(`\nSaved ${outPath}`);
}

main();
